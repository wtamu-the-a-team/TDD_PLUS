from django.apps import AppConfig


class Abet_Form_Config(AppConfig):
    name = 'abet_form'
